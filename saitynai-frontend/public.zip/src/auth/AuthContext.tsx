import React, { createContext, useContext, useMemo, useState } from "react";
import { apiFetch } from "../api/http";
import type { LoginDto, RegisterDto } from "../types";

interface AuthContextValue {
  isAuthed: boolean;
  login(dto: LoginDto): Promise<void>;
  register(dto: RegisterDto): Promise<void>;
  logout(): Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [token, setToken] = useState<string | null>(() =>
    localStorage.getItem("accessToken")
  );

  async function login(dto: LoginDto) {
    await apiFetch<void, LoginDto>("/User/login", {
      method: "POST",
      body: dto,
    });
    const accessToken = await apiFetch<string>("/User/accessToken", {
      method: "POST",
    });
    localStorage.setItem("accessToken", accessToken);
    setToken(accessToken);
  }

  async function register(dto: RegisterDto) {
    await apiFetch<void, RegisterDto>("/User/register", {
      method: "POST",
      body: dto,
    });
    await login({ username: dto.username, password: dto.password });
  }

  async function logout() {
    try {
      await apiFetch<void>("/User/logout", { method: "POST" });
    } finally {
      localStorage.removeItem("accessToken");
      setToken(null);
    }
  }

  const value = useMemo(
    () => ({ isAuthed: Boolean(token), login, register, logout }),
    [token]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used inside AuthProvider");
  return ctx;
}
