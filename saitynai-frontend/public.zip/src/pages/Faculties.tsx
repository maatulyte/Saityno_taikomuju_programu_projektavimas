import { useEffect, useState } from "react";
import { apiFetch } from "../api/http";
import type { Faculty } from "../types";
import { Link } from "react-router-dom";

export default function Faculties() {
  const [items, setItems] = useState<Faculty[]>([]);

  useEffect(() => {
    apiFetch<Faculty[]>("/Faculty").then(setItems);
  }, []);

  return (
    <div>
      <h2>Faculties</h2>
      {items.map((f) => (
        <div key={f.id}>
          <Link to={`/faculties/${f.id}`}>{f.name}</Link>
        </div>
      ))}
    </div>
  );
}
