import { useParams } from "react-router-dom";
import { useEffect, useState } from "react";
import { apiFetch } from "../api/http";
import type { Faculty, Group } from "../types";

export default function FacultyDetail() {
  const { id } = useParams<{ id: string }>();
  const facultyId = Number(id);

  const [faculty, setFaculty] = useState<Faculty | null>(null);
  const [groups, setGroups] = useState<Group[]>([]);

  useEffect(() => {
    apiFetch<Faculty>(`/Faculty/${facultyId}`).then(setFaculty);
    apiFetch<Group[]>(`/Faculty/${facultyId}/mentors/groups`).then(setGroups);
  }, [facultyId]);

  return (
    <div>
      <h2>{faculty?.name}</h2>
      <h3>Groups</h3>
      {groups.map((g) => (
        <div key={g.id}>{g.name}</div>
      ))}
    </div>
  );
}
